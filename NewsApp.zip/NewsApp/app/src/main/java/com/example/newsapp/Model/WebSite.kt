package com.example.newsapp.Model

class WebSite {
    var status:String? = null
    var sources:List<Source>? = null

    constructor()
}