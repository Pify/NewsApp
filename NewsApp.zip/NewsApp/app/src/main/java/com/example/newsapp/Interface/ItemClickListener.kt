package com.example.newsapp.Interface

import android.view.View

interface ItemClickListener {
    fun Onclick(view: View, position: Int)
}